---
title: Chat square quote fill
categories:
  - Communications
tags:
  - chat bubble
  - text
  - message
  - quote
---

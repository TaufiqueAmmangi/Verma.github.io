---
title: Badge 8k fill
categories:
  - Badges
tags:
  - 4k
  - display
  - resolution
  - retina
---

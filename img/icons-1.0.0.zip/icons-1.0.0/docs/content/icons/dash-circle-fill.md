---
title: Dash circle fill
categories:
  - UI and keyboard
tags:
  - minus
---
